# -*- coding: utf-8 -*-
"""
Generador de dataset SINTETICO: autogeneracion solar fotovoltaica residencial, Popayan (Cauca).
Semilla fija -> reproducible. Todos los datos son sinteticos (no provienen de encuesta real).
"""
import numpy as np, pandas as pd

SEED, N = 2026, 1000
rng = np.random.default_rng(SEED)

def wchoice(opts, w):
    w = np.array(w, float); w = w / w.sum()
    return opts[rng.choice(len(opts), p=w)]

def clip(x, lo, hi): return max(lo, min(hi, x))

# ---------- Estructura muestral ----------
strata = np.array([1]*650 + [2]*200 + [3]*150); rng.shuffle(strata)       # 65/20/15 %
rural = np.zeros(N, bool)
for s, k in {1: 355, 2: 95, 3: 50}.items():                               # 500 rurales / 500 urbanos
    rural[rng.choice(np.where(strata == s)[0], k, replace=False)] = True
jefe_m = np.zeros(N, bool); jefe_m[rng.choice(N, 520, replace=False)] = True   # 52% M

BARRIOS = {
 1: ["Alfonso López","Pandiguando","Los Naranjos","Villa del Norte","La Paz","Moscopán","El Placer","Suárez","Bello Horizonte","Santa Catalina","Tomás Cipriano","Los Sauces","Nueva Colombia","Yambitará","Ciudad Jardín Sur"],
 2: ["Pubenza","La Esmeralda","Campanario Sur","Valencia","El Empedrado","Berlín","Lomas de Granada","Chamizal","Los Álamos","Bosques de Pomona","Palacé","Morinda"],
 3: ["Bolívar","Campanario","Modelo","Los Cámbulos","La Aldea","El Recuerdo","Las Palmas","Colombia","Las Américas","Ciudad Jardín"]}
CORREG = ["Calibío","Cajete","Clarete","Julumito","Pueblillo","Pomona","Quintana","Santa Rosa","Yanaconas","La Meseta","Figueroa","Poblazón","Puelenje","Samuel Silverio","Torres","Las Huacas","Tunia"]
VEREDAS = ["El Roble","La Cabaña","Los Cerillos","San Isidro","El Placer","Alto Cauca","Primavera","La Playa","El Rosal","Buenos Aires","Los Pinos","El Retiro"]

STR = {1: dict(inc=(400e3,1.2e6), cons=(60,120),  tar=(700,780), area=(58,10,40,90),   per=[.06,.14,.20,.24,.16,.11,.06,.03],
               edu=[.38,.42,.14,.06], neve2=.03, nev0=.10, tv=[.08,.62,.26,.04], lav=.25, pc=[.62,.30,.07,.01], esp=[.35,.50,.15], sub=.93, med=.06, apt=.03),
       2: dict(inc=(1e6,2.5e6),   cons=(100,180), tar=(760,850), area=(78,14,50,120),  per=[.09,.18,.25,.25,.13,.06,.03,.01],
               edu=[.15,.42,.27,.16], neve2=.10, nev0=.03, tv=[.03,.45,.40,.12], lav=.60, pc=[.35,.40,.20,.05], esp=[.15,.50,.35], sub=.55, med=.12, apt=.10),
       3: dict(inc=(2e6,4e6),     cons=(150,280), tar=(840,950), area=(110,25,70,200), per=[.12,.22,.27,.24,.10,.04,.01,0.0],
               edu=[.06,.28,.30,.36], neve2=.25, nev0=.01, tv=[.01,.25,.45,.29], lav=.90, pc=[.12,.40,.35,.13], esp=[.05,.40,.55], sub=0.0, med=.25, apt=.25)}

BASE_H = np.array([.020,.015,.013,.012,.013,.022,.050,.062,.050,.038,.033,.040,
                   .060,.058,.044,.036,.034,.042,.065,.085,.085,.070,.045,.028])
SOL_W = np.zeros(24)
for h in range(6, 18): SOL_W[h] = np.sin(np.pi*(h+0.5-6)/12)**1.3
SOL_W /= SOL_W.sum()

PANELS_W = [400, 430, 450, 500, 525, 550]
DISC, ESC, DEG, OM, RESID = 0.10, 0.05, 0.005, 0.01, 0.30   # supuestos financieros (ver diccionario)
EXPORT_VAL = 0.35                                           # valor excedentes / tarifa (supuesto)

def tir(cf):
    f = lambda r: sum(c/(1+r)**t for t, c in enumerate(cf))
    lo, hi = -0.60, 1.0
    if f(lo) < 0: return lo
    for _ in range(100):
        mid = (lo+hi)/2
        if f(mid) > 0: lo = mid
        else: hi = mid
    return (lo+hi)/2

rows = []
for i in range(N):
    s = int(strata[i]); P = STR[s]; r = bool(rural[i]); d = {}
    # ---- A ----
    d["id_hogar"] = f"H{i+1:04d}"
    d["zona"] = "Rural" if r else "Urbana"
    if r:
        d["comuna"] = str(rng.choice(CORREG)); d["barrio"] = "Vereda " + str(rng.choice(VEREDAS)); tv_ = "Vivienda rural"
    else:
        d["comuna"] = f"Comuna {rng.integers(1,10)}"; d["barrio"] = str(rng.choice(BARRIOS[s]))
        tv_ = "Apartamento" if rng.random() < P["apt"] else "Casa"
    d["estrato"] = s; d["tipo_vivienda"] = tv_
    # ---- B ----
    n = int(rng.choice(np.arange(1,9), p=np.array(P["per"])/sum(P["per"])))
    men = min(int(rng.binomial(n-1, 0.35)), 4); am = min(int(rng.binomial(max(n-1-men,0), 0.18)), 2)
    d.update(num_personas=n, num_menores=men, num_adultos_mayores=am)
    ew = np.array(P["edu"], float)
    if r: ew = ew + np.array([.10,0,-.05,-.05]); ew = np.clip(ew,0.01,None)
    edu_i = int(rng.choice(4, p=ew/ew.sum())); edu = ["Primaria","Secundaria","Técnico","Universitario"][edu_i]
    ow = {1:[.34,.38,.11,.12,.02],2:[.38,.34,.09,.10,.01],3:[.45,.32,.06,.11,.01]}[s]
    ow = np.array(ow); 
    if am > 0: ow = ow + np.array([-.1,0,0,.25,0]); ow = np.clip(ow,0.01,None)
    ocup = wchoice(["Empleado","Independiente","Desempleado","Pensionado","Estudiante"], ow)
    lo, hi = P["inc"]
    ing = lo + (hi-lo)*rng.beta(2, 2.6)
    ing *= [0.88,1.0,1.08,1.2][edu_i] * (0.80 if ocup=="Desempleado" else 1.0) * (0.95 if r else 1.0)
    ing = int(round(clip(ing, lo, hi), -4))
    emp = rng.random() < (0.18 if s==1 else 0.20 if s==2 else 0.15)
    d.update(ingreso_mensual_cop=ing, jefe_hogar_genero="M" if jefe_m[i] else "F", nivel_educativo=edu,
             ocupacion_principal=ocup, tiene_empresa="Sí" if emp else "No")
    # ---- C ----
    a_mu, a_sd, a_lo, a_hi = P["area"]
    area = clip(rng.normal(a_mu + 3*(n-4) + (8 if r else 0), a_sd), a_lo, a_hi); area = int(round(area))
    if tv_ == "Apartamento":
        cub = int(round(clip(rng.uniform(20, 40), 20, area*0.6))); tc = "Losa de concreto"; ori = "Plana"; inc = int(rng.integers(5,9))
    else:
        cub = int(round(clip(area*rng.uniform(0.55,1.0), 20, min(120, area))))
        tcw = {"Teja de barro":[.30,.40,.40],"Zinc":[.30,.12,.05],"Losa de concreto":[.10,.28,.45],"Eternit":[.30,.20,.10]}
        if r: tcw = {"Teja de barro":[.45,.45,.45],"Zinc":[.30,.15,.05],"Losa de concreto":[.02,.15,.38],"Eternit":[.23,.25,.12]}
        tc = wchoice(list(tcw), [tcw[k][s-1] for k in tcw])
        if tc == "Losa de concreto": ori = "Plana"; inc = int(rng.integers(5,9))
        else:
            ori = str(rng.choice(["Norte","Sur","Este","Oeste"]))
            inc = int(rng.integers(20,36) if tc=="Teja de barro" else rng.integers(10,26) if tc=="Zinc" else rng.integers(10,21))
    shade = rng.random() < (0.20 if r else 0.30)
    sdesc = "Ninguna" if not shade else wchoice(["Árboles","Edificios","Postes","Árboles y edificios"], [.45,.30,.10,.15] if not r else [.75,.05,.10,.10])
    d.update(area_vivienda_m2=area, area_cubierta_m2=cub, tipo_cubierta=tc, inclinacion_cubierta_grados=inc,
             orientacion_cubierta=ori, sombras_presentes="Sí" if shade else "No", sombras_descripcion=sdesc)
    # ---- E ----
    nev = 0 if rng.random() < P["nev0"] else (2 if rng.random() < P["neve2"]/(1-P["nev0"]) else 1)
    pnev = int(rng.integers(100, 251)) if nev else 0
    ntv = int(rng.choice(4, p=P["tv"])); ptv = int(rng.integers(50, 151)) if ntv else 0
    nlav = int(rng.random() < P["lav"]); plav = int(rng.integers(400, 801)) if nlav else 0
    nven = int(rng.choice(5, p=[.50,.30,.14,.05,.01])); pven = int(rng.integers(50,101)) if nven else 0
    nled = int(clip(round(area/8 + rng.normal(0,1.5)), 4, 20)); pled = int(rng.integers(9,19))
    npc = int(rng.choice(4, p=P["pc"])); nesp = int(rng.choice(3, p=P["esp"]))
    d.update(num_neveras=nev, potencia_nevera_w=pnev, num_televisores=ntv, potencia_tv_w=ptv, num_lavadoras=nlav,
             potencia_lavadora_w=plav, num_ventiladores=nven, potencia_ventilador_w=pven, num_bombillas_led=nled,
             potencia_bombilla_w=pled, num_computadores=npc, num_equipos_especiales=nesp)
    # ---- D ----
    nev_d = nev*pnev*0.30*24/1000                                   # kWh/dia nevera
    est = (nev_d*30 + ntv*ptv*4.5*30/1000 + nlav*plav*0.8*12/1000 + nven*pven*3*30/1000
           + nled*pled*5*30/1000 + npc*65*5*30/1000 + nesp*12 + 5 + 2.0*n)
    CAL = {1: 0.82, 2: 1.00, 3: 1.18}[s]                            # calibracion al rango de consumo del estrato
    mult = CAL * rng.uniform(0.90, 1.20) * (0.62 + 0.095*n) * (1.10 if emp else 1.0)
    c_lo, c_hi = P["cons"]
    cons = round(clip(est*mult, c_lo, c_hi), 1)
    dia = round(cons/30, 4)
    nev_d = min(nev_d, 0.6*dia); rest = dia - nev_d
    wts = BASE_H.copy(); dm = 1.0
    if ocup in ("Independiente","Desempleado","Pensionado") or emp or am>0 or men>1: dm *= 1.18
    if ocup == "Empleado": dm *= 0.92
    wts[9:17] *= dm; wts *= rng.lognormal(0, 0.10, 24); wts /= wts.sum()
    hr = np.round(nev_d/24 + rest*wts, 4)
    hr[int(np.argmax(hr))] += round(dia - hr.sum(), 4)
    hr = np.round(hr, 4)
    peak_kw = hr.max()*rng.uniform(1.35, 1.9)
    tar = int(rng.integers(P["tar"][0], P["tar"][1]+1)); fact = int(round(cons*tar))
    sub = "Sí" if rng.random() < P["sub"] else "No"
    vs = float(clip(rng.normal(2, 6), -15, 15))
    if vs >= 0: may = wchoice(["Octubre","Noviembre","Diciembre","Abril","Mayo"],[.2,.2,.35,.15,.1]); men_m = wchoice(["Julio","Agosto","Febrero","Septiembre"],[.35,.35,.15,.15])
    else:       may = wchoice(["Julio","Agosto","Diciembre","Enero"],[.3,.3,.25,.15]); men_m = wchoice(["Abril","Mayo","Octubre","Noviembre"],[.3,.3,.2,.2])
    d.update(consumo_kwh_mes=cons, consumo_kwh_dia_promedio=dia, demanda_maxima_kw=round(peak_kw,2),
             factor_carga=round(dia/24/peak_kw,3), costo_factura_mes_cop=fact, tarifa_kwh_cop=tar,
             consumo_anual_kwh=round(12*cons,1), variacion_estacional_pct=round(vs,1), mes_mayor_consumo=may,
             mes_menor_consumo=men_m, tiene_medidor_inteligente="Sí" if rng.random()<P["med"] else "No", recibe_subsidio=sub)
    for h in range(24): d[f"h{h:02d}"] = float(hr[h])
    # ---- G ----
    rad = round(float(rng.uniform(4.0, 4.5)), 2); hsp = round(min(4.5, rad*rng.uniform(1.0, 1.04)), 2)
    pw = int(rng.choice(PANELS_W)); pa = pw/205.0
    tf = min(inc/30, 1.0); of = {"Plana":0.0,"Norte":0.015,"Sur":0.02,"Este":0.06,"Oeste":0.06}[ori]*tf
    sf = rng.uniform(0.82, 0.95) if shade else 1.0
    PR = 0.80*(1-of)*sf
    usable = cub*rng.uniform(0.55, 0.75)*(0.9 if shade else 1.0)
    max_n = int(max(3, min(12, usable//pa, 5000//pw)))
    target = rng.uniform(0.40, 0.75); best = None
    for npan in range(3, max_n+1):
        kwp_ = npan*pw/1000; gen_d = kwp_*hsp*PR; gh = gen_d*SOL_W
        selfc = np.minimum(gh, hr).sum(); exp_ = gen_d - selfc
        ah = min(0.80*fact, (selfc*tar + exp_*tar*EXPORT_VAL)*30)
        pct = ah/fact
        if best is None or abs(pct-target) < best[0]: best = (abs(pct-target), npan, ah, gen_d)
    _, npan, ah, gen_d = best
    kwp = round(npan*pw/1000, 2)
    d.update(radiacion_promedio_kwh_m2_dia=rad, horas_sol_pico=hsp, generacion_potencial_kwp=kwp, num_paneles_estimados=npan,
             potencia_panel_w=pw, area_requerida_m2=round(npan*pa,1), generacion_diaria_estimada_kwh=round(gen_d,2),
             generacion_mensual_estimada_kwh=round(gen_d*30,1))
    # ---- H ----
    ckwp = clip(4.9e6 - 0.28e6*(kwp-1.2) + rng.normal(0, 0.25e6), 3.5e6, 5.0e6); ckwp = int(round(ckwp, -4))
    inv = int(round(kwp*ckwp, -3)); ah = int(round(ah)); pct = round(100*ah/fact, 1)
    ret_m = round(inv/ah, 1)
    cf = [-inv] + [ah*12*((1+ESC)*(1-DEG))**(t-1) - OM*inv + (RESID*inv if t == 10 else 0) for t in range(1, 11)]
    vpn = int(round(sum(c/(1+DISC)**t for t, c in enumerate(cf)), -3)); tr = round(100*tir(cf), 1)
    req = inv > 6*ing or rng.random() < 0.10
    if req:
        w = {1:[.35,.30,.15,.20],2:[.50,.25,.10,.15],3:[.65,.15,.10,.10]}[s]
        fuente = wchoice(["Crédito","FENOGE","FONENERGIA","Cooperación"], w)
    else: fuente = "Propia"
    d.update(inversion_estimada_cop=inv, costo_kwp_cop=ckwp, ahorro_mensual_cop=ah, ahorro_anual_cop=12*ah, porcentaje_ahorro=pct,
             retorno_simple_meses=ret_m, retorno_simple_anios=round(ret_m/12,2), vpn_10_anios_cop=vpn, tir_porcentaje=tr,
             requiere_financiacion="Sí" if req else "No", fuente_financiacion=fuente)
    # ---- I ----
    inet = rng.random() < ({1:(.45,.75),2:(.65,.90),3:(.80,.97)}[s][0 if r else 1])
    smart = rng.random() < (0.95 if inet else 0.65)
    if inet and not smart and npc == 0: smart = True
    sc = 0.8*edu_i/3*1.0 + 1.0*inet + 1.0*smart + 0.3*min(npc,2) - (0.4 if am>0 else 0) + rng.normal(0, 0.4)
    d["_sc"] = sc; d["_aux"] = (inet, smart, edu_i, pct, ret_m, r, s, tv_, cub, emp, ing, n)
    d.update(tiene_internet="Sí" if inet else "No", tiene_smartphone="Sí" if smart else "No")
    rows.append(d)

df = pd.DataFrame(rows)
# apropiacion por cuantiles del score (35% bajo / 40% medio / 25% alto)
q1, q2 = df["_sc"].quantile([.35, .75])
df["nivel_apropiacion_tecnologica"] = np.where(df["_sc"] < q1, "Bajo", np.where(df["_sc"] < q2, "Medio", "Alto"))
IA_W = {"Bajo":[.55,.25,.05,.08,.03,.04],"Medio":[.25,.35,.12,.12,.10,.06],"Alto":[.08,.22,.18,.14,.20,.18]}
IA_O = ["Ninguno","Medición inteligente","Predicción","Mantenimiento","Optimización","Gemelo digital"]
ia, dispS, bar, mot, com, rec, pago, gob = [], [], [], [], [], [], [], []
for _, x in df.iterrows():
    inet, smart, edu_i, pct, ret_m, r, s, tv_, cub, emp, ing, n = x["_aux"]; ap = x["nivel_apropiacion_tecnologica"]
    w = np.array(IA_W[ap], float)
    if not inet and not smart: w = np.array([1,0,0,0,0,0], float)
    elif not smart: w[[2,4,5]] = 0
    ia.append(IA_O[rng.choice(6, p=w/w.sum())])
    apv = {"Bajo":0,"Medio":1,"Alto":2}[ap]
    dispS.append(1.2*(pct-55)/25 + 0.6*apv + 0.5*edu_i/3*2 - 0.8*(ret_m-100)/50 + (0.3 if emp else 0) + rng.normal(0, 0.8))
df["dispositivo_ia_interes"] = ia
sc = np.array(dispS); a, b = np.quantile(sc, [0.60, 0.40])
df["dispuesto_instalar_paneles"] = np.where(sc >= a, "Sí", np.where(sc >= b, "Tal vez", "No"))
for _, x in df.iterrows():
    inet, smart, edu_i, pct, ret_m, r, s, tv_, cub, emp, ing, n = x["_aux"]; ap = x["nivel_apropiacion_tecnologica"]; disp = x["dispuesto_instalar_paneles"]
    mw = {"Ahorro":.50+(.10 if s==1 else 0),"Ambiente":.15,"Independencia":.12+(.08 if r else 0),"Tecnología":.08+(.12 if ap=="Alto" else 0),"Comunidad":.15+(.05 if r else 0)}
    m = wchoice(list(mw), list(mw.values())); mot.append(m)
    bw = {"Costo":.55 if s==1 else .40,"Desconocimiento":.20+(.15 if edu_i<=1 else 0),"Espacio":.08+(.25 if (tv_=="Apartamento" or cub<30) else 0),
          "Confianza":.12,"Trámites":.12+(.06 if edu_i==3 else 0)}
    bb = wchoice(list(bw), list(bw.values())); bar.append(bb)
    gw = {"Costo":[.50,.40,.05,.05],"Espacio":[.35,.35,.10,.20],"Desconocimiento":[.10,.10,.70,.10],"Confianza":[.05,.10,.35,.50],"Trámites":[.05,.10,.20,.65]}[bb]
    gob.append(wchoice(["Subsidios","Financiación","Capacitación","Regulación"], gw))
    pc_ = clip(.35 + (.25 if m=="Comunidad" else 0) + (.10 if r else 0) + (.10 if disp=="Sí" else -.10 if disp=="No" else 0), .05, .90)
    com.append("Sí" if rng.random() < pc_ else "No")
    rec.append("Sí" if rng.random() < clip(.08+.07*edu_i+(.05 if ap=="Alto" else 0), .05, .5) else "No")
    ah_m = x["ahorro_mensual_cop"]
    if disp == "Sí": p = ah_m*rng.uniform(0.3, 1.0)
    elif disp == "Tal vez": p = ah_m*rng.uniform(0.1, 0.5)
    else: p = 0 if rng.random() < 0.8 else rng.uniform(5e3, 15e3)
    pago.append(int(clip(round(p/5000)*5000, 0, 200000)))
df["principal_barrera"] = bar; df["principal_motivacion"] = mot; df["interes_comunidad_energetica"] = com
df["conoce_reciclaje_paneles"] = rec; df["disposicion_pago_mensual_cop"] = pago; df["prioridad_gobierno"] = gob
df = df.drop(columns=["_sc", "_aux"])

ORDER = ["id_hogar","comuna","barrio","estrato","tipo_vivienda","zona",
 "num_personas","num_menores","num_adultos_mayores","ingreso_mensual_cop","jefe_hogar_genero","nivel_educativo","ocupacion_principal","tiene_empresa",
 "area_vivienda_m2","area_cubierta_m2","tipo_cubierta","inclinacion_cubierta_grados","orientacion_cubierta","sombras_presentes","sombras_descripcion",
 "consumo_kwh_mes","consumo_kwh_dia_promedio","demanda_maxima_kw","factor_carga","costo_factura_mes_cop","tarifa_kwh_cop","consumo_anual_kwh",
 "variacion_estacional_pct","mes_mayor_consumo","mes_menor_consumo","tiene_medidor_inteligente","recibe_subsidio",
 "num_neveras","potencia_nevera_w","num_televisores","potencia_tv_w","num_lavadoras","potencia_lavadora_w","num_ventiladores","potencia_ventilador_w",
 "num_bombillas_led","potencia_bombilla_w","num_computadores","num_equipos_especiales"] + [f"h{h:02d}" for h in range(24)] + \
 ["radiacion_promedio_kwh_m2_dia","horas_sol_pico","generacion_potencial_kwp","num_paneles_estimados","potencia_panel_w","area_requerida_m2",
  "generacion_diaria_estimada_kwh","generacion_mensual_estimada_kwh",
  "inversion_estimada_cop","costo_kwp_cop","ahorro_mensual_cop","ahorro_anual_cop","porcentaje_ahorro","retorno_simple_meses","retorno_simple_anios",
  "vpn_10_anios_cop","tir_porcentaje","requiere_financiacion","fuente_financiacion",
  "dispositivo_ia_interes","nivel_apropiacion_tecnologica","tiene_internet","tiene_smartphone","interes_comunidad_energetica","conoce_reciclaje_paneles",
  "dispuesto_instalar_paneles","principal_barrera","principal_motivacion","disposicion_pago_mensual_cop","prioridad_gobierno"]
df = df[ORDER]
df.to_csv("/mnt/user-data/outputs/dataset_solar_popayan.csv", index=False, encoding="utf-8")
print(df.shape)
