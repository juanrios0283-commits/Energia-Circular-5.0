# -*- coding: utf-8 -*-
import pandas as pd, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
OUT = "/mnt/user-data/outputs/"
df = pd.read_csv(OUT + "dataset_solar_popayan.csv")
H = [f"h{h:02d}" for h in range(24)]

SIM = "Sintético (regla de generación)"
D = {  # variable: (grupo, unidad, descripción / regla, fuente)
"id_hogar":("A","código","Identificador único H0001..H1000",SIM),
"comuna":("A","texto","Comuna 1-9 (urbano) o corregimiento (rural)","Divisiones político-administrativas de Popayán; asignación barrio-comuna ilustrativa"),
"barrio":("A","texto","Barrio (urbano, pool por estrato) o vereda ficticia (rural)","Nombres realistas; asignación no catastral"),
"estrato":("A","1-3","Estrato socioeconómico (65/20/15 %)","DANE (estratificación); distribución del prompt"),
"tipo_vivienda":("A","categoría","Casa / Apartamento / Vivienda rural (rural siempre 'Vivienda rural')",SIM),
"zona":("A","categoría","Urbana / Rural (50/50). Variable añadida para facilitar el análisis",SIM),
"num_personas":("B","personas","Tamaño del hogar, distribución por estrato",SIM),
"num_menores":("B","personas","Menores de edad; ≤ 4 y deja al menos 1 adulto",SIM),
"num_adultos_mayores":("B","personas","Adultos mayores; ≤ 2",SIM),
"ingreso_mensual_cop":("B","COP/mes","Ingreso del hogar; rango por estrato, modulado por educación y ocupación","Rangos del prompt"),
"jefe_hogar_genero":("B","M/F","Género del jefe de hogar (52 % M)","Prompt"),
"nivel_educativo":("B","categoría","Primaria/Secundaria/Técnico/Universitario",SIM),
"ocupacion_principal":("B","categoría","Empleado/Independiente/Desempleado/Pensionado/Estudiante",SIM),
"tiene_empresa":("B","Sí/No","Pequeño emprendimiento en el hogar (+10 % consumo)",SIM),
"area_vivienda_m2":("C","m²","Área construida; crece con estrato y tamaño del hogar",SIM),
"area_cubierta_m2":("C","m²","Cubierta disponible; ≤ área de vivienda",SIM),
"tipo_cubierta":("C","categoría","Teja de barro/Zinc/Losa de concreto/Eternit",SIM),
"inclinacion_cubierta_grados":("C","grados","Losa: 5-8°; teja 20-35°; zinc/eternit 10-25°",SIM),
"orientacion_cubierta":("C","categoría","Norte/Sur/Este/Oeste/Plana (Plana = losa)",SIM),
"sombras_presentes":("C","Sí/No","Hay sombras sobre la cubierta",SIM),
"sombras_descripcion":("C","categoría","Ninguna/Árboles/Edificios/Postes/Árboles y edificios (desglose de 'Sí/No + descripción')",SIM),
"consumo_kwh_mes":("D","kWh/mes","Estimado desde electrodomésticos × tamaño del hogar, recortado al rango del estrato","Rangos del prompt"),
"consumo_kwh_dia_promedio":("D","kWh/día","consumo_kwh_mes / 30","Derivada"),
"demanda_maxima_kw":("D","kW","Pico horario × factor 1.35-1.9 (picos sub-horarios)","Derivada del perfil horario"),
"factor_carga":("D","adim.","Potencia media / demanda máxima","Derivada"),
"costo_factura_mes_cop":("D","COP/mes","consumo × tarifa (tarifa efectiva)","Derivada"),
"tarifa_kwh_cop":("D","COP/kWh","E1 700-780, E2 760-850, E3 840-950","Prompt (700-950)"),
"consumo_anual_kwh":("D","kWh/año","12 × consumo mensual","Derivada"),
"variacion_estacional_pct":("D","%","Consumo temporada lluviosa vs seca (+ = lluviosa mayor), N(2,6) recortado ±15","Supuesto"),
"mes_mayor_consumo":("D","mes","Coherente con el signo de la variación estacional",SIM),
"mes_menor_consumo":("D","mes","Siempre distinto del mes mayor",SIM),
"tiene_medidor_inteligente":("D","Sí/No","E1 6 %, E2 12 %, E3 25 %",SIM),
"recibe_subsidio":("D","Sí/No","E1 ~93 %, E2 ~55 %, E3 0 % (Ley 142/1994)","Marco regulatorio colombiano"),
"num_neveras":("E","unid.","0-2",SIM),"potencia_nevera_w":("E","W","100-250; 0 si no hay equipo",SIM),
"num_televisores":("E","unid.","0-3",SIM),"potencia_tv_w":("E","W","50-150; 0 si no hay equipo",SIM),
"num_lavadoras":("E","unid.","0-1",SIM),"potencia_lavadora_w":("E","W","400-800; 0 si no hay equipo",SIM),
"num_ventiladores":("E","unid.","0-4 (clima templado)",SIM),"potencia_ventilador_w":("E","W","50-100; 0 si no hay equipo",SIM),
"num_bombillas_led":("E","unid.","4-20, proporcional al área",SIM),"potencia_bombilla_w":("E","W","9-18",SIM),
"num_computadores":("E","unid.","0-3",SIM),"num_equipos_especiales":("E","unid.","0-2 (microondas, plancha, licuadora...)",SIM),
"radiacion_promedio_kwh_m2_dia":("G","kWh/m²/día","U(4.0, 4.5); microvariación en torno a 4.25","Atlas UPME-IDEAM 2005 (valor del prompt)"),
"horas_sol_pico":("G","h/día","≈ radiación en plano del panel, tope 4.5","Derivada"),
"generacion_potencial_kwp":("G","kWp","n_paneles × potencia_panel; ≤ 5.0","Derivada"),
"num_paneles_estimados":("G","unid.","3-12; limitado por área útil (55-75 % de la cubierta) y 5 kWp; elegido para un % de ahorro objetivo","Dimensionamiento del generador"),
"potencia_panel_w":("G","W","400, 430, 450, 500, 525 o 550",SIM),
"area_requerida_m2":("G","m²","n_paneles × (potencia/205 W/m²)","Derivada (eficiencia 20.5 %)"),
"generacion_diaria_estimada_kwh":("G","kWh/día","kWp × HSP × PR; PR = 0.80 × pérdida orientación × factor sombra","Modelo simplificado"),
"generacion_mensual_estimada_kwh":("G","kWh/mes","30 × generación diaria","Derivada"),
"inversion_estimada_cop":("H","COP","kWp × costo_kwp (redondeo a miles)","Derivada"),
"costo_kwp_cop":("H","COP/kWp","3.5-5.0 M; decrece levemente con la escala",SIM),
"ahorro_mensual_cop":("H","COP/mes","autoconsumo horario × tarifa + excedentes × 35 % tarifa; tope 80 % de la factura","Supuesto (valor excedentes)"),
"ahorro_anual_cop":("H","COP/año","12 × ahorro mensual","Derivada"),
"porcentaje_ahorro":("H","%","ahorro / factura","Derivada"),
"retorno_simple_meses":("H","meses","inversión / ahorro mensual (sin escalamiento)","Derivada"),
"retorno_simple_anios":("H","años","meses / 12","Derivada"),
"vpn_10_anios_cop":("H","COP","VPN a 10 años, tasa 10 %, tarifa +5 %/año, degradación 0.5 %/año, O&M 1 %/año, valor residual 30 % de la inversión","Supuestos del modelo"),
"tir_porcentaje":("H","%","TIR de los mismos flujos; VPN>0 ⇔ TIR>10 %","Derivada"),
"requiere_financiacion":("H","Sí/No","Sí si inversión > 6 × ingreso mensual (más 10 % aleatorio)",SIM),
"fuente_financiacion":("H","categoría","Propia si no requiere; si requiere: Crédito/FENOGE/FONENERGIA/Cooperación",SIM),
"dispositivo_ia_interes":("I","categoría","Medición inteligente/Predicción/Mantenimiento/Optimización/Gemelo digital/Ninguno; 'Ninguno' si no hay internet ni smartphone",SIM),
"nivel_apropiacion_tecnologica":("I","categoría","Bajo/Medio/Alto (35/40/25 %) según educación, internet, smartphone, computadores",SIM),
"tiene_internet":("I","Sí/No","Mayor en urbano y estratos altos",SIM),
"tiene_smartphone":("I","Sí/No","Si hay internet, casi siempre Sí",SIM),
"interes_comunidad_energetica":("I","Sí/No","Mayor si motivación = Comunidad o zona rural",SIM),
"conoce_reciclaje_paneles":("I","Sí/No","Aumenta con educación y apropiación",SIM),
"dispuesto_instalar_paneles":("J","categoría","Sí 40 % / Tal vez 20 % / No 40 % (interés total 60 %)",SIM),
"principal_barrera":("J","categoría","Costo/Desconocimiento/Espacio/Confianza/Trámites",SIM),
"principal_motivacion":("J","categoría","Ahorro/Ambiente/Independencia/Tecnología/Comunidad",SIM),
"disposicion_pago_mensual_cop":("J","COP/mes","0-200 000; 0 en la mayoría de quienes dicen No",SIM),
"prioridad_gobierno":("J","categoría","Subsidios/Financiación/Capacitación/Regulación; coherente con la barrera",SIM)}
for h in H: D[h] = ("F","kWh","Consumo en la hora " + h[1:] + ":00; la suma de h00-h23 = consumo_kwh_dia_promedio","Perfil sintético (picos 06-08, 12-14, 18-22)")

rows = []
for c in df.columns:
    g, u, desc, src = D[c]
    if not pd.api.types.is_numeric_dtype(df[c]):
        tipo = "categórica"; rango = " | ".join(sorted(df[c].unique())) if df[c].nunique() <= 8 else f"{df[c].nunique()} valores distintos"
    else:
        tipo = "entero" if pd.api.types.is_integer_dtype(df[c]) else "decimal"; rango = f"{df[c].min():g} a {df[c].max():g}"
    rows.append([c, g, tipo, u, rango, desc, src])
pd.DataFrame(rows, columns=["variable","grupo","tipo","unidad","rango_observado","descripcion_regla","fuente"]).to_csv(OUT+"diccionario_datos.csv", index=False, encoding="utf-8-sig")

num = df.select_dtypes("number")
st = pd.DataFrame({"media":num.mean(),"mediana":num.median(),"minimo":num.min(),"maximo":num.max(),"desv_est":num.std()}).round(3)
st.index.name = "variable"; st.to_csv(OUT+"estadisticas_descriptivas.csv", encoding="utf-8-sig")
key = ["consumo_kwh_mes","consumo_kwh_dia_promedio","demanda_maxima_kw","factor_carga","costo_factura_mes_cop","generacion_potencial_kwp","inversion_estimada_cop","ahorro_mensual_cop","porcentaje_ahorro","retorno_simple_anios","vpn_10_anios_cop","tir_porcentaje"]
print(st.loc[key].to_string())

# ---- Visualizaciones ----
col = {1:"#c0392b",2:"#e6a817",3:"#2471a3"}
fig, ax = plt.subplots(figsize=(7,4.5))
ax.boxplot([df[df.estrato==s].consumo_kwh_mes for s in (1,2,3)], labels=["Estrato 1","Estrato 2","Estrato 3"], patch_artist=True,
           boxprops=dict(facecolor="#d6eaf8"), medianprops=dict(color="k"))
ax.set_ylabel("Consumo (kWh/mes)"); ax.set_title("Consumo eléctrico mensual por estrato (n=1.000, sintético)"); ax.grid(alpha=.3)
fig.tight_layout(); fig.savefig(OUT+"fig1_consumo_por_estrato.png", dpi=150); plt.close(fig)

fig, ax = plt.subplots(figsize=(7.5,4.5))
for s in (1,2,3): ax.plot(range(24), df[df.estrato==s][H].mean().values*1000, marker="o", ms=3, color=col[s], label=f"Estrato {s}")
ax.set_xticks(range(0,24,2)); ax.set_xlabel("Hora del día"); ax.set_ylabel("Consumo medio (Wh por hora)")
ax.set_title("Perfil horario promedio de demanda por estrato"); ax.legend(); ax.grid(alpha=.3)
fig.tight_layout(); fig.savefig(OUT+"fig2_perfil_horario.png", dpi=150); plt.close(fig)

fig, ax = plt.subplots(figsize=(7.5,4.8))
for s in (1,2,3):
    g = df[df.estrato==s]; ax.scatter(g.inversion_estimada_cop/1e6, g.ahorro_anual_cop/1e6, s=14, alpha=.55, color=col[s], label=f"Estrato {s}")
x = np.linspace(df.inversion_estimada_cop.min()/1e6, df.inversion_estimada_cop.max()/1e6, 50)
for yrs, ls in ((8,"--"),(12,":")): ax.plot(x, x/yrs, "k", ls=ls, lw=1, label=f"Retorno simple {yrs} años")
ax.set_xlabel("Inversión estimada (millones COP)"); ax.set_ylabel("Ahorro anual (millones COP)")
ax.set_title("Inversión vs ahorro anual"); ax.legend(fontsize=8); ax.grid(alpha=.3)
fig.tight_layout(); fig.savefig(OUT+"fig3_inversion_vs_ahorro.png", dpi=150); plt.close(fig)

# ---- Chequeos de coherencia ----
print("\nCHEQUEOS")
print("nulos:", int(df.isna().sum().sum()), "| filas:", len(df))
print("suma horaria = consumo diario:", bool(np.allclose(df[H].sum(axis=1), df.consumo_kwh_dia_promedio, atol=1e-3)))
print("factura = consumo x tarifa:", bool(((df.consumo_kwh_mes*df.tarifa_kwh_cop-df.costo_factura_mes_cop).abs()<=1).all()))
print("ahorro <= factura:", bool((df.ahorro_mensual_cop<=df.costo_factura_mes_cop).all()))
print("área requerida <= área cubierta:", bool((df.area_requerida_m2<=df.area_cubierta_m2).all()))
print("VPN>0 <=> TIR>10 %:", f"{((df.vpn_10_anios_cop>0)==(df.tir_porcentaje>10)).mean():.1%}", "(diferencias por redondeo)")
print("% VPN>0:", f"{(df.vpn_10_anios_cop>0).mean():.1%}", "| TIR 8-20 %:", f"{df.tir_porcentaje.between(8,20).mean():.1%}")
print("retorno fuera de 60-150 meses:", f"{((df.retorno_simple_meses<60)|(df.retorno_simple_meses>150)).mean():.1%}")
print("ahorro en tope 80 %:", f"{(df.porcentaje_ahorro>=79.95).mean():.1%}")
for s,g in df.groupby("estrato"): print(f"E{s}: consumo medio {g.consumo_kwh_mes.mean():.0f} | ingreso medio {g.ingreso_mensual_cop.mean()/1e6:.2f}M | área {g.area_vivienda_m2.mean():.0f} | retorno medio {g.retorno_simple_anios.mean():.1f} años | VPN>0 {(g.vpn_10_anios_cop>0).mean():.0%} | corr(personas,consumo) {g.num_personas.corr(g.consumo_kwh_mes):.2f}")
print("corr inversión-retorno:", round(df.inversion_estimada_cop.corr(df.retorno_simple_meses),2))
print(df.groupby("estrato").recibe_subsidio.apply(lambda s:(s=='Sí').mean()).round(2).to_dict())
print(df.dispuesto_instalar_paneles.value_counts(normalize=True).round(2).to_dict())
print(df.zona.value_counts().to_dict(), df.jefe_hogar_genero.value_counts().to_dict())
print("sin internet ni smartphone con IA != Ninguno:", int(((df.tiene_internet=='No')&(df.tiene_smartphone=='No')&(df.dispositivo_ia_interes!='Ninguno')).sum()))
